# nd113-IntroToSDC
Udacity course notes and work. Contains Python, Julia, Go, and C++

there is a run.sh file that assumes builders are installed and tries to build all files for a given filename

    cd ProjectFolder
 
    ../run.sh projectFilename

will build
- projectFilename.py
- projectFilename.jl
- projectFilename.go
- projectFilename.cpp


