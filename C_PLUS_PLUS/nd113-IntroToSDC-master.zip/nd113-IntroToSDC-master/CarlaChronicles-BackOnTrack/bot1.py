""" Back on Track exercises """
from math import pi

TAU = pi*2

# 2.pi.r = TAU.r
D = 100
R = D/2
print("Circumference: {0}".format(TAU * R))
