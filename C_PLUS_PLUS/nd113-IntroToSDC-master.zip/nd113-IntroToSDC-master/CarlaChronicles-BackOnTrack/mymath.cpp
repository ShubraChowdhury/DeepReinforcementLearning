#include <math.h>

static float TAU = float(M_PI) * 2.0f;
