package mymath

import (
  "math"
)

// Tau not Pi
const Tau = math.Pi * 2
