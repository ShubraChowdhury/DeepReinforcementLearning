""" Tau not pi """
from math import pi

TAU = pi*2
