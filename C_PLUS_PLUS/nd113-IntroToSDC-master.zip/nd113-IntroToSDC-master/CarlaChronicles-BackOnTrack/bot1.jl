
d = 100
r = d/2
τ = π * 2
println( string("Circumference: ", τ*r) )
