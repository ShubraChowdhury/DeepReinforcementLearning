module MyMath

export τ

τ = 2 * π

end
